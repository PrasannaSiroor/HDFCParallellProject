package com.cg.babk.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.bank.service.BankServiceImpl;



public class HDFCBankTest {
	
	@Test
	public void ValidateNameTrue(){
		BankServiceImpl hb = new BankServiceImpl();
		assertEquals(true, hb.validateUserName("Prasanna"));
	}
	
	
	@Test
	public void ValidatePhonNumberTrue(){
		BankServiceImpl hb = new BankServiceImpl();
		assertEquals(true, hb.validatePhoneNumber("8497992099"));
	}
	
	@Test
	public void ValidatePhoneNumber(){
		BankServiceImpl hb = new BankServiceImpl();
		assertEquals(false, hb.validatePhoneNumber("8497992099"));
		assertEquals(false, hb.validatePhoneNumber("7986534025"));
		assertEquals(false, hb.validatePhoneNumber("79865"));
		assertEquals(false, hb.validatePhoneNumber("testing"));
		assertEquals(false, hb.validatePhoneNumber("@#%"));
	}
	
	@Test 
	public void ValidateNameV2(){
		BankServiceImpl hb = new BankServiceImpl();
		assertEquals(false, hb.validateUserName("prasanna345"));
		assertEquals(false, hb.validateUserName("prasanna@3451"));
		assertEquals(false, hb.validateUserName("317890"));
		assertEquals(false, hb.validateUserName("prasanna"));
	}
	
	@Test
	public void ValidateAmountTrue(){
		BankServiceImpl hb = new BankServiceImpl();
		assertEquals(true, hb.validateAmount(100));
	}
	
	@Test 
	public void ValidateAmount(){
		BankServiceImpl hb = new BankServiceImpl();
		assertEquals(false, hb.validateAmount(0));
		assertEquals(false, hb.validateAmount(-133));
	}

}



