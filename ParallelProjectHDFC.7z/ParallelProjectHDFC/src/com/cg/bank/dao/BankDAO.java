package com.cg.bank.dao;

import com.cg.bank.dto.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.exception.InvalidPhoneNumber;
import com.cg.bank.exception.ValidNumber;



public interface BankDAO {
	
	public void createAccount(Customer c);
	public double showBalance (String mobileno) throws InvalidPhoneNumber;
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, double amount) throws BankException;
	public Customer depositAmount (String mobileNo, double amount );
	public Customer withdrawAmount(String mobileNo, double amount) throws BankException;

}
