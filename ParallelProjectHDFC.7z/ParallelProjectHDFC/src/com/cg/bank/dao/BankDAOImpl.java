package com.cg.bank.dao;

import java.util.Map;

import com.cg.bank.dto.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.exception.InvalidPhoneNumber;
import com.cg.bank.exception.ValidNumber;



public class BankDAOImpl implements BankDAO{

	Map<String, Customer> map;

	
	public BankDAOImpl() {
		map = DataContainer.createCollection();
		
		map.put(" 8497992099",new Customer("prasanna","8497992099", 20000) );
		map.put(" 9515655407",new Customer( " kumari", "9515655407", 90000) );
	}
	

	@Override
	public void createAccount(Customer c) {
		// TODO Auto-generated method stub
		
		if(map.get(c.getMobileNumber())!=null){
			System.out.println("Account Exit");
		}else{
		map.put(c.getMobileNumber(), c);
	System.out.println("Account created");
	}
	}
	@Override
	public double showBalance(String mobileno) throws InvalidPhoneNumber{
		// TODO Auto-generated method stub
		Customer cShow = map.get(mobileno);
		double bal = cShow.getAmount1();
		return bal;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, double amount) throws BankException {
		// TODO Auto-generated method stub
		Customer custfunds = map.get(sourceMobileNo);
		Customer custfundr = map.get(targetMobileNo);
		if((custfunds.getAmount1()-amount) >= 0){
			custfundr.setAmount1(custfundr.getAmount1()+amount);
			map.put(targetMobileNo, custfundr);
			custfunds.setAmount1(custfunds.getAmount1()-amount);
			map.put(sourceMobileNo, custfunds);
			
		
			
		}
		else
			throw new BankException("Make sure that overall balance is greater than zero...");

		return custfunds;
	}

	@Override
	public Customer depositAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		Customer custDep = map.get(mobileNo);
		custDep.setAmount1(custDep.getAmount1()+amount);
		map.put(mobileNo, custDep);
		
		return custDep;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, double amount) throws BankException {
		// TODO Auto-generated method stub
		Customer custDep = map.get(mobileNo);
		if((custDep.getAmount1()-amount) >= 0){
			custDep.setAmount1(custDep.getAmount1()-amount);
			map.put(mobileNo, custDep);
		}
		else
			throw new BankException("Unable to withdraw money...\n"
					+ "Make sure that the balance should be greater than or equal to zero");
		return custDep;
	}

}



