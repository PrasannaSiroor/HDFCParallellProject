package com.cg.bank.dto;
	
	public class Customer {
		private String customerName;
		private String mobileNumber;
		private double amount1;	
		public Customer(String name, String mobNo, double amount) {
			// TODO Auto-generated constructor stub
			this.customerName = name;
			this.mobileNumber = mobNo;
			this.amount1 = amount;
		}
		public Customer() {
			// TODO Auto-generated constructor stub
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public double getAmount1() {
			return amount1;
		}
		public void setAmount1(double amount1) {
			this.amount1 = amount1;
		}

		public void fundTransfer(double amount1) {
			this.amount1 = this.amount1 - amount1;
		}
		
		
		@Override
		public String toString() {
			return "CustomerName: " + customerName + ", MobileNumber: "+ mobileNumber + ", Amount: " + amount1;
		}
		
		
		
	}



