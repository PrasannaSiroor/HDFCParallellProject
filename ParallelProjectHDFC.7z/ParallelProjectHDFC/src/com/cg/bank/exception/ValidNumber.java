package com.cg.bank.exception;

public class ValidNumber extends Exception {
	public ValidNumber() {
	
	super("*****Invalid Number*****");
}

}
