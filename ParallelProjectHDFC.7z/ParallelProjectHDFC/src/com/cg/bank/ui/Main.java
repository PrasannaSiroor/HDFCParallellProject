package com.cg.bank.ui;

import java.util.Scanner;

import com.cg.bank.dto.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.exception.InvalidAmount;
import com.cg.bank.exception.InvalidPhoneNumber;
import com.cg.bank.exception.NameException;
import com.cg.bank.exception.ValidNumber;
import com.cg.bank.service.BankService;
import com.cg.bank.service.BankServiceImpl;



public class Main {
	
	public static void main(String[] args) throws InvalidPhoneNumber, InvalidAmount, NameException, BankException , ValidNumber{
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		BankService	service = new BankServiceImpl();
		
		int ch;
		do{
			
			System.out.println("1.=======Customer Account=====");
			System.out.println("2. =====Show Balance=====");
			System.out.println("3. ======Fund Transfer=====");
			System.out.println("4. =======Deposit Amount=====");
			System.out.println("5. ======Withdraw Amount======");
			System.out.println("6. Exit");
			ch = sc.nextInt();
			
			switch (ch) {
			case 1:

		
				
				System.out.println("Enter Customer Name: ");
				String name = sc.next();
				if(!service.validateUserName(name)){
					throw new NameException();
				}
				System.out.println("Enter Mobile Number: ");
				String mobNo = sc.next();
				if(!service.validatePhoneNumber(mobNo)){
					throw new InvalidPhoneNumber();
				}
				System.out.println("Enter Initial Amount: ");
				double amount = sc.nextDouble();
				if(!service.validateAmount(amount)){
					throw new InvalidAmount();
				}
				
				Customer c = new Customer(name, mobNo, amount);
				//Customer cus = null;
				if(service.validateAll(c))
					 service.createAccount(c);
				else
					throw new BankException("=======Invalid details=====");
				//System.out.println(cus);
				//System.out.println("Successfully created new account for "+cus.getCustomerName()+" with "
						//+ "Mobile Number "+cus.getMobileNumber());
				break;
			
			case 2:
				
				System.out.println("Enter an existing mobile number: ");
				String mobNoShow = sc.next();
				if(!service.validatePhoneNumber(mobNoShow)){
					throw new InvalidPhoneNumber();
				}
				
				double balance = service.showBalance(mobNoShow);
				System.out.println("Available balance for the mobile number "+mobNoShow+" is " +balance);
				
				break;
			
			case 3:
				
				System.out.println("Enter your mobile number: ");
				String sourceMobileNo = sc.next();
				if(!service.validatePhoneNumber(sourceMobileNo)){
					throw new InvalidPhoneNumber();
				}
				System.out.println("Enter recipient's mobile number: ");//check whether mobile number exists in the DB/Collections.
				String targetMobileNo = sc.next();
				if(!service.validatePhoneNumber(targetMobileNo)){
					throw new InvalidPhoneNumber();
				}
				System.out.println("Enter the amount that to be transfered: ");
				double amount1 = sc.nextDouble();
				if(!service.validateAmount(amount1)){
					throw new InvalidAmount();
				}
				
				service = new BankServiceImpl();
				Customer funds = null;
				funds = service.fundTransfer(sourceMobileNo, targetMobileNo, amount1);
				System.out.println("Successfully transfered Rs."+amount1+" to "+targetMobileNo+".\n"
						+ "Available balance is Rs. "+funds.getAmount1());
				
				break;
			
			case 4:
				
				System.out.println("Enter your mobile number: ");
				String mobNoDep = sc.next();
				if(!service.validatePhoneNumber(mobNoDep)){
					throw new InvalidPhoneNumber();
				}
				System.out.println("Enter amount that to be deposited: ");
				double amountDep = sc.nextDouble();
				if(!service.validateAmount(amountDep)){
					throw new InvalidAmount();
				}
				
				service = new BankServiceImpl();
				Customer Depamt = service.depositAmount(mobNoDep, amountDep);
				
				System.out.println("Your current balance is Rs."+Depamt.getAmount1());
			
				
				break;
			
			case 5:
				
				System.out.println("Enter your mobile number: ");
				String mobNoWithDraw= sc.next();
				if(!service.validatePhoneNumber(mobNoWithDraw)){
					throw new InvalidPhoneNumber();
				}
				System.out.println("Enter amount that to be withdrawn: ");
				double amountWithDraw = sc.nextDouble();
				if(!service.validateAmount(amountWithDraw)){
					throw new InvalidAmount();
				}
				
				service = new BankServiceImpl();
				Customer custWithD= service.withdrawAmount(mobNoWithDraw, amountWithDraw);
				
				System.out.println("Your current balance is Rs. "+custWithD.getAmount1());
				
				break;
			
			default:
			case 6:
				break;
			}
			
		}while(ch != 6);
		
			
		
	}

}



