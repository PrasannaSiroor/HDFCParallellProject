package com.cg.bank.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.BankDAO;
import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.dto.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.exception.InvalidAmount;
import com.cg.bank.exception.InvalidPhoneNumber;
import com.cg.bank.exception.ValidNumber;

public class BankServiceImpl implements BankService {
	
BankDAO dao;
	
	public BankServiceImpl() {
		dao = new BankDAOImpl();	
	}
	
	@Override
	public boolean validateAll(Customer cust){
		
		boolean bool = false;

		if(validateUserName(cust.getCustomerName()) == true && validatePhoneNumber(cust.getMobileNumber()) == true && validateAmount(cust.getAmount1()) == true)
			bool = true;
		return bool;
	}
	
	@Override
	public boolean validateUserName(String name){
		
		Pattern pattern = Pattern.compile("[A-Z]{1}[a-z]{2,30}");
		Matcher match = pattern.matcher(name);
		boolean bool = match.matches();
		
		return bool;
	}
	
	@Override
	public boolean validatePhoneNumber(String mobileNo){
		
		Pattern pattern = Pattern.compile("[6-9]{1}[0-9]{9}");
		Matcher match = pattern.matcher(mobileNo);
		
		return match.matches();
	}
	
	@Override
	public boolean validateAmount(double amt){
		
		Pattern pattern = Pattern.compile("[1-9]{1}[0-9.]{0,9}");
		Matcher match = pattern.matcher(String.valueOf(amt));
		
		return match.matches();
	}
	
	@Override
	public boolean validateTargetMobNo(String targetMobNo){
		
		Pattern pattern = Pattern.compile("[6-9]{1}[0-9]{9}");
		Matcher match = pattern.matcher(targetMobNo);
		
		return match.matches();
	}

	@Override
	public void createAccount(Customer c) {
		// TODO Auto-generated method stub
	 dao.createAccount(c);
	}

	@Override
	public double showBalance(String mobileno) throws InvalidPhoneNumber{
		// TODO Auto-generated method stub
		double balance = dao.showBalance(mobileno);
		return balance;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, double amount) throws BankException {
		// TODO Auto-generated method stub
		Customer customer = dao.fundTransfer(sourceMobileNo, targetMobileNo, amount);
		return customer;
	}

	@Override
	public Customer depositAmount(String mobileNo, double amount) throws InvalidPhoneNumber, InvalidAmount {
		// TODO Auto-generated method stub
		Customer customer = dao.depositAmount(mobileNo, amount);
		return customer;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, double amount) throws BankException {
		// TODO Auto-generated method stub
		Customer customer = dao.withdrawAmount(mobileNo, amount);
		return customer;
	}

}



